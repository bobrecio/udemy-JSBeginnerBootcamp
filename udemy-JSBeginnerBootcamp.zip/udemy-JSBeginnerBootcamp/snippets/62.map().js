// transform an array using map()

// example 1
var numbers = [5,10,15,20,25];

var triples = numbers.map(function(num){
    return num*3;
})

triples;