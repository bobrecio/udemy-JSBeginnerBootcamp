let outer2 = "outer";
if (true){
    let inner2 = "inner"
}
console.log(outer2 + inner2);