// find the longest word in a phrase of words
// use the split() method
function longestWord(phrase){
    var words = phrase.split(' ');
    var longest = "";
    for (i=0; i < words.length; i++){
        longest = (words[i].length > longest.length) ? words[i] : longest;
    }
    return (longest.length + " letters in '" + longest + "'");
}
