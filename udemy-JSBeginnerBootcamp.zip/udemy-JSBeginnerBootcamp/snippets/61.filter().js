// example 1

var weather = [72.84,34,56,92,24,47,85,72,54];

var goOutside = weather.filter(function(w){
    return w > 70
    });

// example 2
