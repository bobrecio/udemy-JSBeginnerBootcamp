// chop off excess number of elements from the front of an array
// array.splice(start_index,remove,add)

function chopHead(arr,excess){
    arr.splice(0,excess);
    return arr;
}
